MINIMART - WEBSITE MỘT TRANG

Cách chạy:
1. Giải nén minimart-onepage.zip.
2. Mở thư mục và mở index.html bằng trình duyệt.
3. Hoặc mở thư mục trong VS Code, nhấn chuột phải index.html > Open with Live Server.

Toàn bộ giao diện, CSS và JavaScript nằm trong một file index.html.
Các mục Trang chủ / Sản phẩm / Ưu đãi / Giỏ hàng / Thành viên nằm trên cùng một trang.
Tính năng: tìm kiếm, lọc danh mục, sắp xếp, thêm/xóa sản phẩm, tăng giảm số lượng, tính tổng, kiểm tra thông tin đặt hàng, mô phỏng đăng ký/đăng nhập.
Lưu ý: Đây là bản demo học tập, không có backend, không lưu dữ liệu lâu dài và không xử lý thanh toán thật.
